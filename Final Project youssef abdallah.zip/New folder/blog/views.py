from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CommentForm, LoginForm, PostForm, RegistrationForm
from .models import Post


def home(request):
    posts = Post.objects.select_related("user").all()
    return render(request, "home.html", {"posts": posts})


def post_detail(request, post_id):
    post = get_object_or_404(Post.objects.select_related("user"), id=post_id)
    comments = post.comments.select_related("user").all()
    comment_form = CommentForm()

    if request.method == "POST":
        if not request.user.is_authenticated:
            messages.error(request, "Please login to write a comment.")
            return redirect("login")

        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.user = request.user
            comment.post = post
            comment.save()
            messages.success(request, "Your comment was added successfully.")
            return redirect("post_detail", post_id=post.id)

    return render(
        request,
        "post_detail.html",
        {"post": post, "comments": comments, "comment_form": comment_form},
    )


def register_view(request):
    if request.user.is_authenticated:
        return redirect("home")

    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your account was created successfully.")
        return redirect("home")

    return render(request, "register.html", {"form": form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")

    form = LoginForm(request.POST or None, request=request)
    if request.method == "POST" and form.is_valid():
        login(request, form.cleaned_data["user"])
        messages.success(request, "Welcome back!")
        return redirect("home")

    return render(request, "login.html", {"form": form})


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("home")


@login_required
def add_post(request):
    form = PostForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        post = form.save(commit=False)
        post.user = request.user
        post.save()
        messages.success(request, "Your post was published successfully.")
        return redirect("post_detail", post_id=post.id)

    return render(request, "add_post.html", {"form": form})
