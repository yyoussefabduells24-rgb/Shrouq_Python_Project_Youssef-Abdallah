from django.contrib import admin

from .models import Comment, Post, User


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("email", "name", "gender", "is_staff", "is_active")
    list_filter = ("gender", "is_staff", "is_active")
    search_fields = ("email", "name")


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("title", "user", "created_at")
    list_filter = ("created_at",)
    search_fields = ("title", "body", "user__name", "user__email")


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("post", "user", "created_at")
    list_filter = ("created_at",)
    search_fields = ("body", "user__name", "user__email", "post__title")
